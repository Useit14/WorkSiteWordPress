<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать файл в "wp-config.php"
 * и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'useit1wu_base' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'useit1wu_base' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', 'Lpe85*Ze' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу. Можно сгенерировать их с помощью
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}.
 *
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными.
 * Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'M 3V.y*:{I.=6L{QTIBsu]zx!Y(p _mBt6@RX]7Y8xnq1Rtpn<U4<i&PGOqA5rN=' );
define( 'SECURE_AUTH_KEY',  '&KDs3Squ5J7bxbfS59$ tG1KaEAKsC<S&FTw5>%tumCzrw]:%YPr5k{ hG*) c_{' );
define( 'LOGGED_IN_KEY',    'gaX?T20R<5<!p:Lr T1:{CP|B|8`l`0fyL?9BC~p5qZm>5Ks8. =YsM2}[YS6Vge' );
define( 'NONCE_KEY',        '55%[4:_<aTL:Pjpw-$4k9(fmwcYo* 0vK~#}sy7bG>HS{T:e/1b3zV$uq<9bn+h3' );
define( 'AUTH_SALT',        'migolPUDt>meNeu].!{^Ep7?pu]yMNrh4o 51C3j6D):Y5t<[d#<_<tdye8V67%g' );
define( 'SECURE_AUTH_SALT', 'sca!g6&|>]YV@FMs3`8ZnSU@$i#IFx`2T|D`)MBG?jdD.MbHS;c~uC4)a8_84mH}' );
define( 'LOGGED_IN_SALT',   'Weg&i@zVKmM#j=}(S&` TA i09Hr9wL<>`{XU6i.)W?1bn}qtQP=0f_T;v^b9*dH' );
define( 'NONCE_SALT',       'VeX_t$|)TrJ*Ei7txBb)Ph+~!kbEW~Nq/-uWTXzXtwcu.+$ym|s_y[5}}hAQ>vOq' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Произвольные значения добавляйте между этой строкой и надписью "дальше не редактируем". */



/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
